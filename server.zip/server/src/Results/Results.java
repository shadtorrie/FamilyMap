package Results;

public abstract class Results {
    public abstract boolean isSuccess() ;
}
