package Requests;

public class ClearRequest extends  Requests {

}
