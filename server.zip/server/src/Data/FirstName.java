package Data;

public abstract class FirstName {
    public abstract String getRandom();
}
