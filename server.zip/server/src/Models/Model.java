package Models;

public abstract class Model {
    public abstract String getID();
    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}
